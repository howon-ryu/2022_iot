/*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Additions Copyright 2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/**
 * @file aws_iot_certifcates.c
 * @brief File to store the AWS certificates in the form of arrays
 */

#ifdef __cplusplus
extern "C" {
#endif

const char aws_root_ca_pem[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\n\
ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\n\
b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\n\
MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\n\
b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\n\
ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n\
9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\n\
IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\n\
VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n\
93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\n\
jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\n\
AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\n\
A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\n\
U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\n\
N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\n\
o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n\
5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\n\
rqXRfboQnoZsG4q5WTP468SQvvG5\n\
-----END CERTIFICATE-----\n"};

const char certificate_pem_crt[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDWTCCAkGgAwIBAgIUPdP9oVvJHlY4//yoeftCRV9DRiUwDQYJKoZIhvcNAQEL\n\
BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g\n\
SW5jLiBMPVNlYXR0bGUgU1Q9V2FzaGluZ3RvbiBDPVVTMB4XDTIyMDQyODA2MzA1\n\
NloXDTQ5MTIzMTIzNTk1OVowHjEcMBoGA1UEAwwTQVdTIElvVCBDZXJ0aWZpY2F0\n\
ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALRAnaJ5LXDTx65Ey3Cd\n\
kaoOVVy/J8YpmfbzUWirdPWg06lD2piz3sTUZsoA/azm+EPGrrZcv6VjXGp8GGS3\n\
Cg5sfH7Chg9wncYg840TJOU7GL8C82dwAAXhisO3/OAsTKPRwT6ihGUYtOg4Ou/n\n\
vvErZxjCRC/il9B4y+qWa5IaWl9gG8+mlBOfdpYfvDlh3p2qvgdCuk6SgO5BnjwF\n\
D4I5ksPLRUrf2PM99Ir2x0ylWReaoLHrT1CIEvlz/ucm6icZWK/AUoHQ5zE0TMwa\n\
JplrbnOf7N2BjaZ7yBy6edDiM4A3/9soUxPQ7eg3mEO5HiWhRZ1iL3HHnoBuU3J2\n\
0cMCAwEAAaNgMF4wHwYDVR0jBBgwFoAUTd4wNm/4jf7q9ZRIhupxNmcSEqgwHQYD\n\
VR0OBBYEFJ07HO1uMuLLBM0Mwdr77tmmh5hXMAwGA1UdEwEB/wQCMAAwDgYDVR0P\n\
AQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4IBAQAFfC4RN65V0gEQJDBEWhaeIXCk\n\
WPD74JcGLWFwPXEGnlroSpWg6iWQ+9b4IJDMNEV5QWkzqZEVBO7YJ6sKr804+Tki\n\
NfdanEwNszTBgXRLz/q/+T2o8oGVJNRT6/dv0msvRJ/4pSvgifayZCKKEbz8XOtS\n\
scLaVf5P/gOu0xR1eNGOz8eOutYVjXbmsxms8UHGdT4MQoZY8OjJC0/olgszks6f\n\
eRf0haFWIays4AhRDn9LJj6cPfxN0rZY7mUWpTwzY6vVs+BRrieKAWg2aIsfyRWW\n\
WWfsBUqtcJRDeEygOwBO12KPgMtohp7d5NphTL0pOgHKH7zQbxqlVresDZwa\n\
-----END CERTIFICATE-----\n"};

const char private_pem_key[] = {"-----BEGIN RSA PRIVATE KEY-----\n\
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtECdonktcNPHrkTLcJ2R\n\
qg5VXL8nximZ9vNRaKt09aDTqUPamLPexNRmygD9rOb4Q8autly/pWNcanwYZLcK\n\
Dmx8fsKGD3CdxiDzjRMk5TsYvwLzZ3AABeGKw7f84CxMo9HBPqKEZRi06Dg67+e+\n\
8StnGMJEL+KX0HjL6pZrkhpaX2Abz6aUE592lh+8OWHenaq+B0K6TpKA7kGePAUP\n\
gjmSw8tFSt/Y8z30ivbHTKVZF5qgsetPUIgS+XP+5ybqJxlYr8BSgdDnMTRMzBom\n\
mWtuc5/s3YGNpnvIHLp50OIzgDf/2yhTE9Dt6DeYQ7keJaFFnWIvcceegG5TcnbR\n\
wwIDAQAB\n\
-----END RSA PRIVATE KEY-----\n"};


#ifdef __cplusplus
}
#endif
